﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.AspNet.SignalR.Client;
using System.Threading;
using System.Diagnostics;



namespace WebWindows
{
    public partial class Form1 : Form
    {
        HubConnection hubConnection;
        IHubProxy hubProxy;
        public Form1()
        {
            InitializeComponent();
            hubConnection = new HubConnection("http://localhost:3266/signalr/hubs");            
            //hubConnection = new HubConnection("http://localhost:3266//signalr/hubs");            
            hubProxy = hubConnection.CreateHubProxy("chatHub");
            var uiCtx = SynchronizationContext.Current;

            hubProxy.On<string, string, string, string>("messageReceived", (userName, message, time, UserImg) => uiCtx.Post(_ => { lstMessages.Items.Add(userName + message + time + UserImg); opencode(); }, null));


            hubConnection.Start().Wait();

            hubProxy.Invoke("Connect", "Anu").Wait();    
        }        
        private void btn_Submit_Click(object sender, EventArgs e)
        {
           // hubProxy.Invoke("send", textBox1.Text).Wait();  

            hubProxy.Invoke("sendMessageToAll", "anu", textBox1.Text, System.DateTime.Now).Wait();    
        }

        public void opencode()
        {
         //   Process.Start(@"D:\myText.txt");
        }

        private void Form1_Load(object sender, EventArgs e)
        {

            
        }
    }
}
